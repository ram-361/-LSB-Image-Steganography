#ifndef decode_h
#define decode_h
#include "types.h"
#define DEFAULT_FILE_NAME "dec_ram"
typedef struct decode
{
    char *stego_img_name;
    char stego_extn[5];
    FILE *fptr_stego_img;
    char magic[3];
    //decode secret file
    int extn_size;
    char extn[5];
    long secret_file_size;
    char secret_file_name[20];
    FILE *fptr_secret_file;

}decode;
Status read_and_validate_decode_args(int argc,char *argv[],decode *decodeInfo);

Status do_decode(decode *decodeInfo);

Status openfile(decode *decodeInfo);

Status decode_magic_string(decode *decodeInfo);

Status decode_extn_size(decode *decodeInfo);

Status decode_extn(decode *decodeInfo);

Status decode_secret_file_size(decode *decodeInfo);

Status open_secret_file(decode *decodeInfo);

Status decode_secret_data(decode *decodeInfo);

Status decode_data(int size,char *data,decode *decodeInfo);

Status decode_size(int size,decode *decodeInfo);

Status decode_bit_from_lsb(char *buffer,char *data);



#endif