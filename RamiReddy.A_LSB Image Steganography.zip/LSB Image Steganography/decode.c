#include <stdio.h>
#include<string.h>
#include "decode.h"
#include "types.h"
#include "common.h"
Status do_decode(decode *decodeInfo)
{
    printf("INFO: decoding started\n");
    if (openfile(decodeInfo))
    {
        printf("INFO: file opened successful\n");
        rewind(decodeInfo->fptr_stego_img);
        fseek(decodeInfo->fptr_stego_img,54,SEEK_SET);
        if(decode_magic_string(decodeInfo)==e_success){
            printf("INFO: magic string found\n");
            decode_extn_size(decodeInfo);
            decode_extn(decodeInfo);
            strcat(decodeInfo->secret_file_name,decodeInfo->extn);
            open_secret_file(decodeInfo);
            decode_secret_file_size(decodeInfo);
            decode_secret_data(decodeInfo);
        }
        else
        return e_failure;
    }
    
}
Status read_and_validate_decode_args(int argc,char *argv[],decode *decodeInfo)
{
    if(argc<3){
        printf("INFO : minimum 3 arguments required\n");
        return e_failure;
    }
    decodeInfo->stego_img_name=argv[2];
    strcpy(decodeInfo->stego_extn,strchr(decodeInfo->stego_img_name,'.'));
    if (strcmp(decodeInfo->stego_extn,".bmp")!=0)
    {
        printf("Info:encoded file should be '.bmp' file\n");
        return e_failure;
    }
    if (argc==4)
    {
       strcpy(decodeInfo->secret_file_name,argv[3]);
    }
    else
    strcpy(decodeInfo->secret_file_name,DEFAULT_FILE_NAME);
    return e_success;
}
Status openfile(decode *decodeInfo){
    decodeInfo->fptr_stego_img = fopen(decodeInfo->stego_img_name, "r");
    if (decodeInfo->fptr_stego_img == NULL)
    {
    	perror("fopen");
        
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decodeInfo->stego_img_name);

    	return e_failure;
    }
}
Status decode_extn_size(decode *decodeInfo){
    decode_size(32,decodeInfo);
    printf("INFO: decoding extn size successful\n");
}
Status decode_size(int size,decode *decodeInfo){
    unsigned long int temp=0;
    char buffer;
    for (int i = 0; i < size; i++)
    {
        int get_bit=0;
        fread(&buffer,1,1,decodeInfo->fptr_stego_img);
        get_bit=buffer&1;
        temp=temp|(get_bit<<i);
    }
    if (size==32)
    {
        decodeInfo->extn_size=temp;
    }
    else
    decodeInfo->secret_file_size=temp;
    
}
Status decode_bit_from_lsb(char *buffer,char *data){
    char temp=0;
    for (int i = 0; i < 8; i++)
    {
        char get_bit=buffer[i]&1;
        temp=temp|(get_bit<<i);
    }
    *data=temp;
}
Status decode_data(int size,char *data,decode *decodeInfo){
    char buffer[8];
    for (int i = 0; i < size; i++)
    {
        fread(buffer,8,1,decodeInfo->fptr_stego_img);
        decode_bit_from_lsb(buffer,data+i);
    }
    
}
Status decode_magic_string(decode *decodeInfo){
    decode_data(2,decodeInfo->magic,decodeInfo);
    decodeInfo->magic[2]='\0';
    if (strcmp(decodeInfo->magic,MAGIC_STRING)==0)
    {
        return e_success;
    }
    else{
        return e_failure;
    }
    
}
Status decode_extn(decode *decodeInfo){
    decode_data(decodeInfo->extn_size,decodeInfo->extn,decodeInfo);
    decodeInfo->extn[decodeInfo->extn_size]='\0';
    printf("INFO: decoding extn successful\n");
}
Status open_secret_file(decode *decodeInfo){
    decodeInfo->fptr_secret_file = fopen(decodeInfo->secret_file_name, "w");
    // Do Error handling
    if (decodeInfo->fptr_secret_file == NULL)
    {
    	perror("fopen");
        
    	fprintf(stderr, "ERROR: Unable to open file %s\n", decodeInfo->secret_file_name);

    	return e_failure;
    }
    else
    printf("INFO: secret file opened successfully\n");
}
Status decode_secret_file_size(decode *decodeInfo){
    decode_size(64,decodeInfo);
    printf("INFO: secret file size decoding successful\n");
}
Status decode_secret_data(decode *decodeInfo){
    char buffer[decodeInfo->secret_file_size];
    decode_data(decodeInfo->secret_file_size,buffer,decodeInfo);
    fwrite(buffer,decodeInfo->secret_file_size,1,decodeInfo->fptr_secret_file);
    fclose(decodeInfo->fptr_secret_file);
    fclose(decodeInfo->fptr_stego_img);
    printf("INFO:decoding completed successfully\n");
}