#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
int main(int argc,char *argv[])
{
    EncodeInfo encInfo;
    decode decodeInfo;
    uint img_size;
    if(argc==1)
    {
        printf("INFO: minimum 4 arguments required\n");
        return 0;
    }
    int op=check_operation_type(argv[1]);
    if(op==e_encode)
    {
        if(read_and_validate_encode_args(argc,argv,&encInfo)==e_failure)
        {
            return e_failure;
        }
        encInfo.src_image_fname=argv[2];
        encInfo.secret_fname=argv[3];
        printf("%s",encInfo.src_image_fname);
        printf("%s",encInfo.secret_fname);
        if(argv[4]!=NULL)
        {
            encInfo.stego_image_fname=argv[4];
        }
        do_encoding(&encInfo);
    }
    else if(op==e_decode)
    {
        if(read_and_validate_decode_args(argc,argv,&decodeInfo)==e_success)
        {
            do_decode(&decodeInfo);
        }    
    }
    else
    {
        printf("INFO :Enter -e or -d for encoding or decoding");
        return 0;
    }
}
OperationType check_operation_type(char *argv)
{
    if(strcmp(argv,"-e")==0)
    {
        return e_encode;
    }
    else if(strcmp(argv,"-d")==0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}
